from tkinter import *
from PIL import Image, ImageTk
import time, threading
from tkinter import font
import tkinter as tk


# Create a window
window = Tk()

# Set the window size
window.geometry("600x900")

# Set the background color of the window
window.configure(bg = "white")

# Create and place a canvas on the window
canvas = Canvas(window, width=600, height=900, bg="light blue")
canvas.place(x=0, y=0)


fortniteFont = font.Font(family="Impact", size=11, weight=font.BOLD, slant=font.ITALIC)


imageCookie = Image.open('vBucks.png').convert('RGBA')
resizedCookie = imageCookie.resize((150, 150), Image.Resampling.LANCZOS)
changedCookie = ImageTk.PhotoImage(resizedCookie)
imgCookie = canvas.create_image(250, 200, image = changedCookie)
canvas.itemconfig(imgCookie, state='hidden')

resizedCookieS3 = imageCookie.resize((100, 100), Image.Resampling.LANCZOS)
changedCookieS3 = ImageTk.PhotoImage(resizedCookieS3)
imgCookieS3 = canvas.create_image(250, 200, image = changedCookieS3)
canvas.itemconfig(imgCookieS3, state='hidden')

resizedCookieS2 = imageCookie.resize((150, 150), Image.Resampling.LANCZOS)
changedCookieS2 = ImageTk.PhotoImage(resizedCookieS2)
imgCookieS2 = canvas.create_image(250, 200, image = changedCookieS2)
canvas.itemconfig(imgCookieS2, state='hidden')

resizedCookieS1 = imageCookie.resize((200, 200), Image.Resampling.LANCZOS)
changedCookieS1 = ImageTk.PhotoImage(resizedCookieS1)
imgCookieS1 = canvas.create_image(250, 200, image = changedCookieS1)
canvas.itemconfig(imgCookieS1, state='normal')

clickAmount = 1
money = 0
moneyText = StringVar()
moneyText.set("$ " + str(money))
moneyLabel = Label(window, textvariable=moneyText,
                    fg="black", bg="light Grey", width=20, font=fortniteFont)
moneyLabel.place(x = 150, y = 2)


def cookieClicked(e):
    global imgCookie
    global clickAmount
    global money
    global cookieStageNum
    if e.num == 1:

        runClickAnimation()
        money = int(money) + int(clickAmount)
        moneyText.set("$ " + str(money) + "\n $ Per Click: " + str(clickAmount) + "\n $ Per Second: " + str(autoClickAmount))
        
cookieStageNum = 1
def runClickAnimation():
    global cookieStageNum

    if cookieStageNum == 1:
        canvas.itemconfig(imgCookie, state='hidden')
        canvas.itemconfig(imgCookieS1, state='normal')
    
    if cookieStageNum == 2:
        canvas.itemconfig(imgCookieS1, state='hidden')
        canvas.itemconfig(imgCookieS2, state='normal')
    
    if cookieStageNum == 3:
        canvas.itemconfig(imgCookieS2, state='hidden')
        canvas.itemconfig(imgCookieS3, state='normal')
    
    if cookieStageNum == 4:
        canvas.itemconfig(imgCookieS3, state='hidden')
        canvas.itemconfig(imgCookieS2, state='normal')
    
    if cookieStageNum == 5:
        canvas.itemconfig(imgCookieS2, state='hidden')
        canvas.itemconfig(imgCookieS1, state='normal')

  
    cookieStageNum = cookieStageNum + 1
    if cookieStageNum == 6:
        cookieStageNum = 1
    else:
        threading.Timer(0.05, runClickAnimation).start()

def doTimerStuff():
    global money

    money = money + 1
    moneyText.set("$ " + str(money) + "\n $ Per Click: " + str(clickAmount) + "\n $ Per Second: " + str(autoClickAmount))

    # Keep calling this function over and over
    threading.Timer(1.0, doTimerStuff).start()

canvas.tag_bind(imgCookieS1, "<Button-1>", cookieClicked)
canvas.tag_bind(imgCookieS2, "<Button-1>", cookieClicked)
canvas.tag_bind(imgCookieS3, "<Button-1>", cookieClicked)

imagePickaxe1 = Image.open('Pickaxe1.png').convert('RGBA')
resizedPickaxe1 = imagePickaxe1.resize((50, 75), Image.Resampling.LANCZOS)
changedPickaxe1 = ImageTk.PhotoImage(resizedPickaxe1)
imgPickaxe1 = canvas.create_image(140, 130, image = changedPickaxe1)
canvas.itemconfig(imgPickaxe1, state='hidden')


def pickaxeUpgrade():
    
    global money
    global pickUpCost
    global clickAmount
    if money >= pickUpCost:
        canvas.itemconfig(imgPickaxe1, state='normal')
        money = int(money) - int(pickUpCost)
        clickAmount = int(clickAmount) * 2
        moneyText.set("$ " + str(money) + "\n $ Per Click: " + str(clickAmount) + "\n $ Per Second: " + str(autoClickAmount))
        pickUpCost = int(pickUpCost) * 2
        PickaxeUpgrade1.config(text= "Pickaxe $ " + str(pickUpCost))
pickUpCost = 50

PickaxeUpgrade1 = Button(window, text = "Pickaxe $ " + str(pickUpCost), font=fortniteFont, bd = '3', command = pickaxeUpgrade)
PickaxeUpgrade1.place(x = 360, y = 115 )

autoClickAmount = 0 
def autoClick():
    global autoClickAmount 
    global money
    money = money + autoClickAmount
    moneyText.set("$ " + str(money) + "\n $ Per Click: " + str(clickAmount) + "\n $ Per Second: " + str(autoClickAmount))
    threading.Timer(1.0, autoClick).start()
autoClick()

def onHenchEnter(e):
    global henchCost
    henchMenUpgrade.config(text="Cost: " + str(henchCost) + "\nPlus 5 To AutoClick")
    

def buyHenchMenUpgrade():
    
    global money
    global henchCost
    global autoClickAmount
    if money >= henchCost:
        canvas.itemconfig(imgHenchMen, state='normal')
        money = int(money) - int(henchCost)
        autoClickAmount = int(autoClickAmount) + 5
        moneyText.set("$ " + str(money) + "\n $ Per Click: " + str(clickAmount) + "\n $ Per Second: " + str(autoClickAmount))
        henchCost = int(henchCost) * 2
        henchMenUpgrade.config(text= "HenchMen $ " + str(henchCost), font=fortniteFont, bd = '3', command = buyHenchMenUpgrade)
henchCost = 1000

henchMenUpgrade = Button(window, text = "HenchMen $ " + str(henchCost), font=fortniteFont, bd = '3', command = buyHenchMenUpgrade)
henchMenUpgrade.place(x = 360, y = 150 )
henchMenUpgrade.bind("<Enter>", onHenchEnter)

imageHenchMen = Image.open('Henchmen.png').convert('RGBA')
resizedHenchMen = imageHenchMen.resize((150, 150), Image.Resampling.LANCZOS)
changedHenchMen = ImageTk.PhotoImage(resizedHenchMen)
imgHenchMen = canvas.create_image(140, 300, image = changedHenchMen)
canvas.itemconfig(imgHenchMen, state='hidden')
window.mainloop()