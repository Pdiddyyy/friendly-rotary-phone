from tkinter import *
from PIL import Image, ImageTk
import time, threading
from tkinter import font

# Create a window
window = Tk()

# Set the window size
window.geometry("600x900")

# Set the background color of the window
window.configure(bg = "white")

# Create and place a canvas on the window
canvas = Canvas(window, width=600, height=900, bg="light blue")
canvas.place(x=0, y=0)


fortniteFont = font.Font(family="Impact", size=11, weight=font.BOLD, slant=font.ITALIC)


imageCookie = Image.open('vBucks.png').convert('RGBA')
resizedCookie = imageCookie.resize((150, 150), Image.Resampling.LANCZOS)
changedCookie = ImageTk.PhotoImage(resizedCookie)
imgCookie = canvas.create_image(250, 200, image = changedCookie)
canvas.itemconfig(imgCookie, state='hidden')

resizedCookieS3 = imageCookie.resize((100, 100), Image.Resampling.LANCZOS)
changedCookieS3 = ImageTk.PhotoImage(resizedCookieS3)
imgCookieS3 = canvas.create_image(250, 200, image = changedCookieS3)
canvas.itemconfig(imgCookieS3, state='hidden')

resizedCookieS2 = imageCookie.resize((150, 150), Image.Resampling.LANCZOS)
changedCookieS2 = ImageTk.PhotoImage(resizedCookieS2)
imgCookieS2 = canvas.create_image(250, 200, image = changedCookieS2)
canvas.itemconfig(imgCookieS2, state='hidden')

resizedCookieS1 = imageCookie.resize((200, 200), Image.Resampling.LANCZOS)
changedCookieS1 = ImageTk.PhotoImage(resizedCookieS1)
imgCookieS1 = canvas.create_image(250, 200, image = changedCookieS1)
canvas.itemconfig(imgCookieS1, state='normal')

clickAmount = 1
money = 0
moneyText = StringVar()
moneyText.set("💰: $ " + str(money) + "\n" + str(clickAmount))

moneyLabel = Label(window, textvariable=moneyText,
                    fg="blue", bg="pink", width=20)
moneyLabel.place(x = 150, y = 2)

clickAmount = 1
def cookieClicked(e):
    global imgCookie
    global clickAmount
    global money
    global cookieStageNum
    if e.num == 1:

        runClickAnimation()
        money = int(money) + int(clickAmount)
        moneyText.set("💰: $ " + str(money) + "\n" + str(clickAmount))
        
cookieStageNum = 1
def runClickAnimation():
    global cookieStageNum

    if cookieStageNum == 1:
        canvas.itemconfig(imgCookie, state='hidden')
        canvas.itemconfig(imgCookieS1, state='normal')
    
    if cookieStageNum == 2:
        canvas.itemconfig(imgCookieS1, state='hidden')
        canvas.itemconfig(imgCookieS2, state='normal')
    
    if cookieStageNum == 3:
        canvas.itemconfig(imgCookieS2, state='hidden')
        canvas.itemconfig(imgCookieS3, state='normal')
    
    if cookieStageNum == 4:
        canvas.itemconfig(imgCookieS3, state='hidden')
        canvas.itemconfig(imgCookieS2, state='normal')
    
    if cookieStageNum == 5:
        canvas.itemconfig(imgCookieS2, state='hidden')
        canvas.itemconfig(imgCookieS1, state='normal')

  
    cookieStageNum = cookieStageNum + 1
    if cookieStageNum == 6:
        cookieStageNum = 1
    else:
        threading.Timer(0.05, runClickAnimation).start()

def doTimerStuff():
    global money

    money = money + 1
    moneyText.set("Player 1 money: " + str(money))

    # Keep calling this function over and over
    threading.Timer(1.0, doTimerStuff).start()

canvas.tag_bind(imgCookieS1, "<Button-1>", cookieClicked)
canvas.tag_bind(imgCookieS2, "<Button-1>", cookieClicked)
canvas.tag_bind(imgCookieS3, "<Button-1>", cookieClicked)

PickaxeUpgradeCost = 20
def purchasePickaxeUpgrade():
    global cost
    global money
    global clickAmount
    global PickaxeUpgradeCost
    PickaxeCost = 20
    money = int(money) - int(PickaxeUpgradeCost) 
    clickAmount = int(clickAmount) * 1.5
    PickaxeUpgradeCost = PickaxeUpgradeCost * 1.25 

    
        
def PickaxeStats():
    global cost
    global PickaxeUpgradeCost
    cost = 0
    cost = PickaxeUpgradeCost
    purchasePickaxeUpgrade()
    PickaxeUpgradeCost = int(cost) * 1.25 

PickaxeUpgradeCost = 20
cost = 0 
imagePickaxe1 = Image.open('Pickaxe1.png').convert('RGBA')
resizedPickaxe1 = imagePickaxe1.resize((50, 75), Image.Resampling.LANCZOS)
changedPickaxe1 = ImageTk.PhotoImage(resizedPickaxe1)
imgPickaxe1 = canvas.create_image(140, 130, image = changedPickaxe1)
canvas.itemconfig(imgPickaxe1, state='normal')

PickaxeUpgrade1 = Button(window, text = "PICKAXE\n" + str(PickaxeUpgradeCost), font=fortniteFont, bd = '3', command = purchasePickaxeUpgrade())
PickaxeUpgrade1.place(x = 360, y = 115 )


window.mainloop()